//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by BOOKMFCBUTTONTEST.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_BOOKMFC_BUTTON_TEST_DIALOG  102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG_NEW_WINDOW           130
#define IDD_DIALOG_PAINT                132
#define IDD_DIALOG_CHANGE_CONFIG_COLOR  134
#define IDD_DIALOG_CHANGE_CONFIG_TEXT_SIZE 135
#define IDD_DIALOG_TEST_SPLITTER        138
#define IDD_DIALOG_PAINT_MENU           139
#define IDD_DIALOG_PAINT_DRAW           140
#define IDC_BUTTON_HELLO                1000
#define IDC_BUTTON_EXIT                 1001
#define IDC_EDIT1                       1002
#define IDC_STATIC_CUR_TIME             1003
#define IDC_EDIT_NUM                    1004
#define IDC_BUTTON_ADD                  1005
#define IDC_BUTTON_SUB                  1006
#define IDC_BUTTON_MUL                  1007
#define IDC_BUTTON_DIV                  1008
#define IDC_BUTTON_EQU                  1009
#define IDC_STATIC_BEFORE_NUM           1010
#define IDC_STATIC_EQUAL                1011
#define IDC_BUTTON_NEW_WINDOW_1         1012
#define IDC_BUTTON_NEW_WINDOW_2         1013
#define IDC_BUTTON_NEW_WINDOW_3         1014
#define IDC_STATIC_NEW_WINDOW           1014
#define IDC_BUTTON_NEW_WINDOW_4         1015
#define IDC_BUTTON1                     1015
#define IDC_BUTTON_NEW_WINDOW_5         1016
#define IDC_BUTTON_COLOR_RED            1016
#define IDC_BUTTON_CHANGE_TEXT_SIZE     1016
#define IDC_BUTTON_GOTO_PAINT           1017
#define IDC_BUTTON_COLOR_YELLOW         1017
#define IDC_STATIC_PAINT_STATUS         1018
#define IDC_BUTTON_COLOR_GREEN          1018
#define IDC_BUTTON_COLOR_ORANGE         1019
#define IDC_BUTTON_COLOR_BLACK          1020
#define IDC_BUTTON_TEXT_SIZE_UP         1021
#define IDC_BUTTON_TEXT_SIZE_DOWN       1022
#define IDC_STATIC_TEXT_SIZE            1023
#define IDC_BUTTON_TEXT_SIZE_COLLECT    1024

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        140
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1024
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
