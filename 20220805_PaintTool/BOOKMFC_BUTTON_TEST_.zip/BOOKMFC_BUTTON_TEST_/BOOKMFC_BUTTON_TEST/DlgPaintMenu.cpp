// DlgPaintMenu.cpp : implementation file
//

#include "pch.h"
#include "BOOKMFC_BUTTON_TEST.h"
#include "DlgPaintMenu.h"
#include "afxdialogex.h"


// cDlgPaintMenu dialog

IMPLEMENT_DYNAMIC(cDlgPaintMenu, CDialogEx)

cDlgPaintMenu::cDlgPaintMenu(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG_PAINT_MENU, pParent)
{

}

cDlgPaintMenu::~cDlgPaintMenu()
{
}

void cDlgPaintMenu::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(cDlgPaintMenu, CDialogEx)
END_MESSAGE_MAP()


// cDlgPaintMenu message handlers
