// RW_txt.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <string>
#include <string.h>
#include <stdio.h>
#include <Windows.h>
#include <codecvt>

using namespace std;

struct _utf8 {
    int del_len = 3;
    int bom[3] = { 239,187,191 };
};

struct _utf16le {
    int del_len = 2;
    int bom[2] = { 255, 254 };
};

struct _utf8 utf8bom;
struct _utf16le utf16lebom;


int checkBOM(string str);
int strLength(string str);
DWORD convertAnsiToUnicode(wstring& unicode, const char* ansi, const size_t ansi_size);
DWORD convertUnicodeToUtf8(string& utf8, const wchar_t* unicode, const size_t unicode_size);

int main()
{
    string name = "\n�赵���Դϴ�.";
    wstring unicode = L"";
    string utf8 = "";
    string unicodeToMulti = "";
    convertAnsiToUnicode(unicode, name.c_str(), name.size());
    convertUnicodeToUtf8(utf8, unicode.c_str(), unicode.size());

    string filePath = "C:\\AAA\\";
    string fileFormat = ".txt";
    string a_spell = "A";
    string a_str = "";
    
    string readFileName = "";
    string writeFileName = "";
    string line;
    int len;
    int bomCheck;
    for (int i = 1; i <= 3; i++) {
        a_str = a_spell + to_string(i);
        readFileName = filePath + a_str + fileFormat;
        writeFileName = filePath + a_str + "_" + to_string(i) + fileFormat;
        cout << writeFileName << endl;
        //EF BB BF -> BOM
        //FF FE -> UTF-16 LE

        wstring wstr;

        ifstream openFile(readFileName.data());
        ofstream writeFile(writeFileName);
        if (openFile.is_open()) {
           while (getline(openFile, line)) {
               //writeFile << line << endl << "�赵���Դϴ�.";
               len = strLength(line);
               bomCheck = checkBOM(line);
               switch (bomCheck) {
               case 0:
                   writeFile << line << name;
                   break;
               case 1:
                   //line = line.substr(utf8bom.del_len-1, line.length());
                   writeFile << line;
                   writeFile << utf8;
                   break;
               case 3:
                   writeFile << line;
                   
                   //issue : UTF-16 LE �������� �ۼ� �� 16������ ���� Ȥ�� �����Ͱ� �ùٸ��� ����
                   basic_ofstream<char16_t> u16writeFile;
                   u16writeFile.open(writeFileName, ios_base::out | ios_base::app);
                   wstring_convert<codecvt_utf8_utf16<char16_t, 0x10ffffff, codecvt_mode::little_endian>, char16_t> cnv;
                   u16string s = cnv.from_bytes(utf8);
                   u16writeFile << s;
                   
                   
                   break;
               }
           }
        }
    }
}

//���� https://wendys.tistory.com/84
DWORD convertAnsiToUnicode(wstring& unicode,const char* ansi,const size_t ansi_size) {
    DWORD error = 0;
    
    do {
        if ((nullptr == ansi) || (0 == ansi_size)) {
            error = ERROR_INVALID_PARAMETER;
            break;
        }
        unicode.clear();

        int required_cch = MultiByteToWideChar(CP_ACP, 0, ansi, static_cast<int>(ansi_size), nullptr, 0);

        if (0 == required_cch) {
            error = GetLastError();
            break;
        }

        unicode.resize(required_cch);

        if (0 == MultiByteToWideChar(CP_ACP, 0, ansi, static_cast<int>(ansi_size), const_cast<wchar_t*>(unicode.c_str()), static_cast<int>(unicode.size()))) {
            error = GetLastError();
            break;
        }

    } while (false);
    
    return error;
}

//���� https://wendys.tistory.com/84
DWORD convertUnicodeToUtf8(string& utf8, const wchar_t* unicode, const size_t unicode_size) {
    DWORD error = 0;

    do {
        if ((nullptr == unicode) || (0 == unicode_size)) {
            error = ERROR_INVALID_PARAMETER;
            break;
        }
        utf8.clear();

        int required_cch = WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, unicode, static_cast<int>(unicode_size), nullptr, 0, nullptr, nullptr);

        if (0 == required_cch) {
            error = GetLastError();
            break;
        }

        utf8.resize(required_cch);

        if (0 == WideCharToMultiByte(CP_UTF8, WC_ERR_INVALID_CHARS, unicode, static_cast<int>(unicode_size), const_cast<char*>(utf8.c_str()), static_cast<int>(utf8.size()), nullptr, nullptr)) {
            error = GetLastError();
            break;
        }

    } while (false);

    return error;
}

int strLength(string str) {
    int i = 0,count = 0;
    for (int i = 0; str[i]; i++) {
        //MSB check
        if ((str[i] >> 7))
            i++;
        count++;
    }
    return count;
}

int checkBOM(string str){
    
    //  0 -> ANSI
    //  1 -> UTF-8 BOM
    //  3 -> UTF-16 LE

    int checkbom = 0;
    const char* buffer = str.c_str();

    if ((unsigned char)str[0] == utf8bom.bom[0] && (unsigned char)str[1] == utf8bom.bom[1] && (unsigned char)str[2] == utf8bom.bom[2])
        checkbom = 1;
    else if ((unsigned char)str[0] == utf16lebom.bom[0] && (unsigned char)str[1] == utf16lebom.bom[1])
        checkbom = 3;
    else
        checkbom = 0;
    return checkbom;
}

