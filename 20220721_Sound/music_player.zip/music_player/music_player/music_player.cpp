// music_player.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "main_header.h"
#include "wav_player.h"
#include "mp3_header.h"
#include "ogg_header.h"
#include "mid_header.h"

#include <mmsystem.h>
#include <Vfw.h>

#pragma comment(lib,"winmm.lib")

#include <tchar.h>

UINT wDeviceID = 0;

DWORD playWAVFile(HWND hWndNotify, LPCTSTR lpszWAVEFileName) {
    UINT wDeviceID;
    DWORD dwReturn;
    MCI_OPEN_PARMS mciOpenParms;
    MCI_PLAY_PARMS mciPlayParms;

    // Open the device by specifying the device and filename.
    // MCI will choose a device capable of playing the specified file.

    TCHAR mciErrorString[128];

    UINT mciErrorLen = 128;
    BOOL KnownError = FALSE;

    setlocale(LC_ALL, "");

    mciOpenParms.lpstrDeviceType = _T("mpegvideo");
    mciOpenParms.lpstrElementName = lpszWAVEFileName;
    if (dwReturn = mciSendCommand(NULL, MCI_OPEN,
        MCI_OPEN_TYPE | MCI_OPEN_ELEMENT,
        (DWORD)(LPVOID)&mciOpenParms))
    {
        // Failed to open device. Don't close it; just return error.
        mciGetErrorString(dwReturn, mciErrorString, mciErrorLen);
        _tprintf(_T("%s\n"), mciErrorString);
        return (dwReturn);
    }

    // The device opened successfully; get the device ID.
    wDeviceID = mciOpenParms.wDeviceID;

    // Begin playback. The window procedure function for the parent 
    // window will be notified with an MM_MCINOTIFY message when 
    // playback is complete. At this time, the window procedure closes 
    // the device.

    mciPlayParms.dwCallback = (DWORD)hWndNotify;
    mciSendCommand(0, MCI_SEEK, MCI_SEEK_TO_START, (DWORD)(LPVOID)NULL);
    dwReturn = mciSendCommand(0, MCI_PLAY,MCI_NOTIFY, (DWORD)(LPVOID)&mciPlayParms);
    mciGetErrorString(dwReturn, mciErrorString, mciErrorLen);
    _tprintf(_T("%s\n"), mciErrorString);
    /*
        if (dwReturn = mciSendCommand(0, MCI_PLAY, MCI_NOTIFY, (DWORD)(LPVOID)&mciPlayParms)){
        mciSendCommand(wDeviceID, MCI_CLOSE, 0, NULL);
        return (dwReturn);
    }
    */
    printf("\n");
    return (0L);
}

int returnLength(const wchar_t* a) {
    int count = 0;
    while (a[count] != NULL) {
        count++;
    }
    return count;
}

TCHAR* checkingFileType(LPCWSTR file) {
    TCHAR* type = 0;
    int check = 0,length = 0;
    
    if ((_tcsstr(file, L"wav")) || _tcsstr(file, L"WAV")) {
        length = returnLength(_T("waveaudio"));
        type = (TCHAR*)malloc(length);
        _tcscpy(type, _T("waveaudio"));
    }
    else if ((_tcsstr(file, L"ogg")) || _tcsstr(file, L"OGG")) {
        length = returnLength(_T("mpegvideo"));
        type = (TCHAR*)malloc(length);
        _tcscpy(type, _T("mpegvideo"));
    }
    else if ((_tcsstr(file, L"mp3")) || _tcsstr(file, L"MP3")) {
        length = returnLength(_T("mpegvideo"));
        type = (TCHAR*)malloc(length);
        _tcscpy(type, _T("mpegvideo"));
    }
    else if ((_tcsstr(file, L"mid")) || _tcsstr(file, L"MID")) {
        length = returnLength(_T("mpegvideo"));
        type = (TCHAR*)malloc(length);
        _tcscpy(type, _T("mpegvideo"));
    }
    else {
        length = returnLength(_T("mpegvideo"));
        type = (TCHAR*)malloc(length);
        _tcscpy(type, _T("mpegvideo"));
    }


    return type;
}

DWORD playMusic(HWND hWnd, LPCTSTR lpszWave) {

    MCI_OPEN_PARMS mciOpen;
    MCI_PLAY_PARMS mciPlay;
    DWORD error = 0;
    int dwID = 0;
    int result = 0;

    TCHAR mciErrorString[128];

    UINT mciErrorLen = 128;
    BOOL KnownError = FALSE;

    setlocale(LC_ALL, "");

    //open
    mciOpen.lpstrElementName = lpszWave;

    mciOpen.lpstrDeviceType = checkingFileType(lpszWave);

    _tprintf(L"���� �̸� : %s\n", lpszWave);

    //open
    result = mciSendCommand(0, MCI_OPEN, MCI_OPEN_TYPE | MCI_OPEN_ELEMENT, (DWORD)(LPVOID)&mciOpen);
    mciGetErrorString(result, mciErrorString, mciErrorLen);
    //_tprintf(_T("%s\n"), mciErrorString);
    dwID = mciOpen.wDeviceID;

    //seek
    result = mciSendCommand(dwID, MCI_SEEK, MCI_SEEK_TO_START, (DWORD)(LPVOID)NULL);
    mciGetErrorString(result, mciErrorString, mciErrorLen);
    //_tprintf(_T("%s\n"), mciErrorString);

    printf("\"Ctrl+c\" click to end of application\n");
    //play
    mciPlay.dwCallback = (DWORD)hWnd;
    result = mciSendCommand(dwID, MCI_PLAY, MCI_NOTIFY | MCI_WAIT, (DWORD)(LPVOID)&mciPlay);
    mciGetErrorString(result, mciErrorString, mciErrorLen);
    //_tprintf(_T("%s\n"), mciErrorString);

    /*
    result = mciSendString(L"open C:\\AAA\\covid_sample.wav type waveaudio alias mp3", NULL, 0, NULL);
    mciGetErrorString(result, mciErrorString, mciErrorLen);
    _tprintf(_T("%s\n"), mciErrorString);
    result = mciSendString(L"play mp3 from 0 to 10000 wait", NULL, 0, NULL);
    mciGetErrorString(result, mciErrorString, mciErrorLen);
    _tprintf(_T("%s\n"), mciErrorString);
    */
    return 0;
}

void selectMusic() {
    int choice = 0;
    while (1) {
        printf("-- sample music -- \n");
        printf("1. WAV (covid_sample.wav)\n");
        printf("2. OGG (Sample2.ogg)\n");
        printf("3. MP3 (Sample3.mp3)\n");
        printf("4. MID (Sample4.mid)\n");
        printf("0. EXIT\n");
        printf("-> ");
        scanf("%d", &choice);

        switch (choice) {
        case 1:
            playMusic(NULL, _T(SAMPLE_WAV));
            break;
        case 2:
            playMusic(NULL, _T(SAMPLE_OGG));
            break;
        case 3:
            playMusic(NULL, _T(SAMPLE_MP3));
            break;
        case 4:
            playMusic(NULL, _T(SAMPLE_MID));
            break;
        case 0:
            printf("\nExit Bye.\n");
            exit(1);
            break;
        default:
            printf("\nretry to choice.\n");
            break;
        }
    }
}

//SAMPLE_WAV
int main()
{

    selectMusic();
    
    //WAV ��� - ���� �ڵ� ��ġ �� WAV�� ��������� ���� Ȯ��.
    //PlaySound(_T(SAMPLE_WAV), NULL, SND_FILENAME);
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
