#pragma once

#define SAMPLE_MP3 "C:\\AAA\\Sample3.mp3"

/*
typedef struct wav_header_riff {
    unsigned char c_chunkId[4] = { "" };
    unsigned int chunkSize;                 //LE
    unsigned char format[4] = { "" };
}WAV_HEADER_RIFF;

typedef struct wav_header_format {
    unsigned char c_chunkId[4] = { "" };        //������ "fmt+(space)"
    unsigned int chunkSize;                     //LE
    unsigned short c_audioFormat;               //LE
    unsigned short numberOfChannel;             //LE
    unsigned int sampleRate;                    //LE
    unsigned int byteRate;                      //LE
    unsigned short blockAlign;                  //LE, size of sample frame. ex) numberOfChannel is 1(mono), sample * 1
    unsigned short bitPerSample;                //LE
}WAV_HEADER_FORMAT;

typedef struct wav_header_data {
    unsigned char c_chunkId[4] = { "" };        //������ "data"
    unsigned int size;                          //LE
}WAV_HEADER_DATA;

typedef struct wav_header {
    WAV_HEADER_RIFF wav_riff;
    WAV_HEADER_FORMAT wav_format;
    WAV_HEADER_DATA wav_data;
}WAV_HEADER;
*/