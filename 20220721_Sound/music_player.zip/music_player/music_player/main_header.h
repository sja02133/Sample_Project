#pragma once

#define _CRT_SECURE_NO_WARNINGS


#include <iostream>
#include <stdio.h>
#include <windows.h>
#pragma comment(lib, "ws2_32.lib")