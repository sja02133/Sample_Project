#pragma once

#define SAMPLE_OGG "C:\\AAA\\Sample2.ogg"