#pragma once

#define SAMPLE_MID "C:\\AAA\\Sample4.mid"